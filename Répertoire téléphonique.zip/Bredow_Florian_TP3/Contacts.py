# Créé le 06/12/2021 en Python 3.7

import csv


# Fonction qui affiche le menu et retourne le choix
def Menu():
    # Définition d'un tuple pour affichage du menu
    Menu = ("1. Créer un nouveau contact",
            "2. Modifier un contact",
            "3. Supprimer un contact",
            "4. Importer des contacts",
            "5. Parcourir le répertoire",
            "6. Rechercher un contact",
            "0. Quitter")
    # Affichage du menu
    for i in Menu:
        print(i)
    # Demande du choix
    choix = input("Faites votre choix: ")
    # Gestion de l'erreur du choix dans le menu
    test = True
    while test:
        try:
            choix = int(choix)
            test = False
        except ValueError:
            print("Le choix doit être 0, 1, 2, 3, 4, 5 ou 6.")
            choix = input("Faites votre choix: ")
    return choix


# Fonction qui permet de creer un contact
def Creer_Contact(contact):
    '''
    Fonction permettant de créer un nouveau contact, si il n'existe pas.
    Il faut d'abord entrer le nom, puis le numéro de téléphone.
    Le numéro de téléphone peut contenir l'indicatif du pays, sans espace
    entre l'indicatif et le numéro de téléphone.
    Si le contact entré est en doublon, vous serez renvoyé au menu.
    '''
    # Demande d'entrer le nom
    cle = input("Entrez le nom: ")
    # La clé saisie n'est pas dans le répertoire, demande de saisir le numéro
    if cle not in contact:
        valeur = str(input("Entrez le numéro de téléphone: "))
        test = True
        while test:
            try:
                valeur == int(valeur)
                test = False
            except ValueError:
                print("Saisissez un numéro de téléphone.")
                valeur = str(input("Entrez un numéro de téléphone: "))
        contact[cle] = valeur
        print("Le contact a été ajouté! ")
    # La clé saisie existe déja dans le répertoire, informe que la clé existe
    else:
        print("Le contact existe déjà.")


# Fonction qui permet de modifier un contact existant
def Modifier_Contact(contact):
    '''
    Fonction qui permet de modifier le nom ou le numéro d'un contact
    existant, ou de retourner au menu. Si le contact n'existe pas, vous serez
    renvoyé au menu principal.
    '''
    # Si le répertoire est vide, informe que celui-ci est vide
    if len(contact) == 0:
        print("Le répertoire est vide.")
    else:
        # Définition d'un tuple pour afficher le menu de la fonction modifier
        Sous_Menu = ("1. Modifier le numéro",
                     "2. Modifier le nom",
                     "3. Retour au menu.")
        # Affichage du menu
        for i in Sous_Menu:
            print(i)
        # Demande du choix
        choix = input("Faites votre choix: ")
        # Gestion de l'erreur du choix dans le menu de la fonction modifier
        test = True
        while test:
            try:
                choix = int(choix)
                test = False

            except ValueError:
                print("Le choix doit être 1, 2 ou 3.")
                choix = input("Faites votre choix: ")

        # Modification du numéro du contact
        if choix == 1:
            # Demande le nom du contact dont le nom est à modifier
            num_modif = input("Entrez le nom du contact à modifier: ")
            # Si le contact existe, demande le nouveau nom
            if num_modif in contact:
                contact[num_modif] = input("Entrez le nouveau numéro: ")
            # Si le contact n'existe pas, renvoie l'information
            else:
                print("Le contact n'existe pas ! ")
        # Modification du nom du contact
        elif choix == 2:
            # Demande le nom du contact dont le numéro est à modifier
            nom_modif = input("Entrez le nom du contact à modifier: ")
            # Le contact existe, demande le nouveau numéro et supprime l'ancien
            if nom_modif in contact:
                nouveau_nom = input("Entrez le nouveau nom: ")
                contact[nouveau_nom] = contact[nom_modif]
                del contact[nom_modif]
            # Si le contact existe pas, renvoie l'information
            else:
                print("Le contact n'existe pas ! ")
        # Retour au menu
        elif choix == 3:
            print("Retour au menu")
        # Erreur lors du choix, redemande du choix
        elif choix != 1 or 2 or 3:
            print("Choix impossible")
            choix = Modifier_Contact(contact)


# Fonction pour supprimer un contact
def Supprimer_Contact(contact):
    '''
    La fonction qui permet de supprimer un contact du répertoire,
    si il existe. Il faut entrer le nom, il sera supprimé.
    Si le contact n'existe pas, vous serez renvoyé au menu.
    '''
    # Si le répertoire est vide, renvoie l'information
    if len(contact) == 0:
        print("Le répertoire est vide.")
    else:
        # Demande le contact à supprimer
        sup_contact = input("Entrez le nom du contact à supprimer: ")
        # Le contact existe, il est supprimé
        if sup_contact in contact:
            del contact[sup_contact]
            print("Le contact a été supprimé.")
        # Le contact n'existe pas, renvoie l'information
        else:
            print("Le contact n'existe pas.")


# Fonction pour importer un répertoire en fichier csv
def Importer_Contact(contact):
    '''
    La fonction sert à importer un répertoire téléphonique qui a été créé
    en fichier csv. Il faut entrer le nom du fichier avec l'extension .csv
    Si le nom du fichier est faux, il faut le resaisir correctement.
    Si les contacts importés existent déjà, l'ancien numéro est gardé.
    '''
    # Demande le nom du fichier
    nom_fichier = input("Entrez le nom du fichier avec l'extension .csv: ")
    test = True
    while test:
        try:
            # Le fichier existe, les contacts sont importés
            with open(nom_fichier, "r") as fichier:
                donnees = csv.DictReader(fichier, delimiter=";")
                for row in donnees:
                    cle = row['nom']
                    valeur = row['numero']
                    if cle not in contact:
                        contact[cle] = valeur
                    else:
                        print("Le contact", cle, "existe déjà.")
                print("Le fichier a bien été importé.")
                test = False
        # Le fichier n'existe pas, demande à nouveau le nom
        except FileNotFoundError:
            print("Le nom du fichier n'est pas correct.")
            nom_fichier = input("Entrez le nom du fichier csv: ")


# Fonction qui affiche le répertoire dans l'ordre alphabétique
def Parcourir_rep(contact):
    '''
    La fonction affiche le répertoire complet dans l'ordre alphabétique.
    '''
    # Le répertoire est vide, renvoie l'information
    if len(contact) == 0:
        print("Le répertoire est vide.")
    # Le répertoire contient un contact, il est affiché
    else:
        for k in sorted(contact.keys()):
            print("%s: %s" % (k, contact[k]))


# Fonction pour rechercher un contact
def Rechercher_Contact(contact):
    '''
    La fonction permet de rechercher un contact dans le répertoire.
    Il faut entrer le nom du contact, il sera affiché.
    '''
    # Le répertoire est vide, renvoie l'information
    if len(contact) == 0:
        print("Le répertoire est vide.")
    else:
        # Demande le nom du contact
        nom = input("Entrez le nom recherché: ")
        test = True
        while test:
            try:
                # Recherche le contact et l'affiche
                recherche = contact[nom]
                print("Le numéro de téléphone est:", recherche)
                test = False
            # Le contact n'existe pas, renvoie l'information
            except KeyError:
                print("Le contact n'existe pas. ")
                break


def main():
    contact = {}
    # Initialisation de la valeur du choix pour entrer dans la boucle
    choix = -1
    # Boucle pour le menu
    while choix != 0:
        choix = Menu()
        if choix == 1:
            Creer_Contact(contact)
        elif choix == 2:
            Modifier_Contact(contact)
        elif choix == 3:
            Supprimer_Contact(contact)
        elif choix == 4:
            Importer_Contact(contact)
        elif choix == 5:
            Parcourir_rep(contact)
        elif choix == 6:
            Rechercher_Contact(contact)
        elif choix != 0:
            print("Choix impossible")

main()
